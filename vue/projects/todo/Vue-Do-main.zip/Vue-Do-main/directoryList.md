|-- undefined
    |-- .gitignore
    |-- babel.config.js
    |-- jsconfig.json
    |-- package-lock.json
    |-- package.json
    |-- README.md
    |-- vue.config.js
    |-- public
    |   |-- favicon.ico
    |   |-- index.html
    |   |-- README.md
    |-- src
    |   |-- App.vue
    |   |-- main.js
    |   |-- README.md
    |   |-- assets
    |   |   |-- logo.png
    |   |   |-- README.md
    |   |-- components
    |   |   |-- README.md
    |   |   |-- body
    |   |   |   |-- README.md
    |   |   |   |-- ToDoItem.vue
    |   |   |   |-- ToDoItems.vue
    |   |   |-- header
    |   |       |-- README.md
    |   |       |-- ToDoHeader.vue
    |   |       |-- ToDoInput.vue
    |   |-- store
    |       |-- README.md
    |       |-- todoStore.js
    |-- ss
        |-- README.md
        |-- vueDo.PNG
